/*
 * main.h
 *
 *  Created on: 14 sty 2025
 *      Author: mikol
 */

#ifndef MAIN_MAIN_H_
#define MAIN_MAIN_H_


bool is_wifi_connected(void);


#endif /* MAIN_MAIN_H_ */
